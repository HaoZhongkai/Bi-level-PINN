"""Package for jax NN modules."""

from .fnn import FNN

__all__ = ["FNN"]
