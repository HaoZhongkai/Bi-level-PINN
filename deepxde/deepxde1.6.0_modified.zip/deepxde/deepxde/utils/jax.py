"""Utilities of jax."""
