"""Utilities of pytorch."""
