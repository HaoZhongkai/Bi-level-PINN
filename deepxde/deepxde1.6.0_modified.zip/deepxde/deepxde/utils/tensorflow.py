"""Utilities of tensorflow."""
