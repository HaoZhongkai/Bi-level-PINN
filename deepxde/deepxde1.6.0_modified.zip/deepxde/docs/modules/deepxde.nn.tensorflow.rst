deepxde.nn.tensorflow
=====================

deepxde.nn.tensorflow.deeponet module
-------------------------------------

.. automodule:: deepxde.nn.tensorflow.deeponet
   :members:
   :undoc-members:
   :show-inheritance:

deepxde.nn.tensorflow.fnn module
--------------------------------

.. automodule:: deepxde.nn.tensorflow.fnn
   :members:
   :undoc-members:
   :show-inheritance:

deepxde.nn.tensorflow.nn module
-------------------------------

.. automodule:: deepxde.nn.tensorflow.nn
   :members:
   :undoc-members:
   :show-inheritance:

