deepxde.backend package
=======================

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   deepxde.backend.pytorch
   deepxde.backend.tensorflow
   deepxde.backend.tensorflow_compat_v1

Submodules
----------

deepxde.backend.backend module
------------------------------

.. automodule:: deepxde.backend.backend
   :members:
   :undoc-members:
   :show-inheritance:

deepxde.backend.set\_default\_backend module
--------------------------------------------

.. automodule:: deepxde.backend.set_default_backend
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: deepxde.backend
   :members:
   :undoc-members:
   :show-inheritance:
