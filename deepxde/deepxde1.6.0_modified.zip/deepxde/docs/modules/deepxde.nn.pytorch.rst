deepxde.nn.pytorch
==================

deepxde.nn.pytorch.fnn module
-----------------------------

.. automodule:: deepxde.nn.pytorch.fnn
   :members:
   :undoc-members:
   :show-inheritance:

deepxde.nn.pytorch.nn module
----------------------------

.. automodule:: deepxde.nn.pytorch.nn
   :members:
   :undoc-members:
   :show-inheritance:

