deepxde.optimizers.tensorflow\_compat\_v1 package
=================================================

Submodules
----------

deepxde.optimizers.tensorflow\_compat\_v1.optimizers module
-----------------------------------------------------------

.. automodule:: deepxde.optimizers.tensorflow_compat_v1.optimizers
   :members:
   :undoc-members:
   :show-inheritance:

deepxde.optimizers.tensorflow\_compat\_v1.scipy\_optimizer module
-----------------------------------------------------------------

.. automodule:: deepxde.optimizers.tensorflow_compat_v1.scipy_optimizer
   :members:
   :undoc-members:
   :show-inheritance:

deepxde.optimizers.tensorflow\_compat\_v1.tfp\_optimizer module
---------------------------------------------------------------

.. automodule:: deepxde.optimizers.tensorflow_compat_v1.tfp_optimizer
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: deepxde.optimizers.tensorflow_compat_v1
   :members:
   :undoc-members:
   :show-inheritance:
