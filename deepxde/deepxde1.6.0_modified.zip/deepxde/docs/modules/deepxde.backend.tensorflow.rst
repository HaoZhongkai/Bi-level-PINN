deepxde.backend.tensorflow package
==================================

Submodules
----------

deepxde.backend.tensorflow.tensor module
----------------------------------------

.. automodule:: deepxde.backend.tensorflow.tensor
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: deepxde.backend.tensorflow
   :members:
   :undoc-members:
   :show-inheritance:
