deepxde.backend.tensorflow\_compat\_v1 package
==============================================

Submodules
----------

deepxde.backend.tensorflow\_compat\_v1.tensor module
----------------------------------------------------

.. automodule:: deepxde.backend.tensorflow_compat_v1.tensor
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: deepxde.backend.tensorflow_compat_v1
   :members:
   :undoc-members:
   :show-inheritance:
