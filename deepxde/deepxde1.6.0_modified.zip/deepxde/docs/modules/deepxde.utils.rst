deepxde.utils
=============

deepxde.utils.external module
-----------------------------

.. automodule:: deepxde.utils.external
   :members:
   :undoc-members:
   :show-inheritance:

