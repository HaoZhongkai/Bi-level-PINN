deepxde.icbcs
=============

deepxde.icbcs.boundary\_conditions module
-----------------------------------------

.. automodule:: deepxde.icbcs.boundary_conditions
   :members:
   :undoc-members:
   :show-inheritance:

deepxde.icbcs.initial\_conditions module
----------------------------------------

.. automodule:: deepxde.icbcs.initial_conditions
   :members:
   :undoc-members:
   :show-inheritance:

