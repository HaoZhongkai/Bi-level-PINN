deepxde.nn
==========

deepxde.nn.activations module
-----------------------------

.. automodule:: deepxde.nn.activations
   :members:
   :undoc-members:
   :show-inheritance:

deepxde.nn.initializers module
------------------------------

.. automodule:: deepxde.nn.initializers
   :members:
   :undoc-members:
   :show-inheritance:

deepxde.nn.regularizers module
------------------------------

.. automodule:: deepxde.nn.regularizers
   :members:
   :undoc-members:
   :show-inheritance:

