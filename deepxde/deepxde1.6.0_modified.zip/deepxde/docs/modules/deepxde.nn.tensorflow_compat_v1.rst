deepxde.nn.tensorflow\_compat\_v1
=================================

deepxde.nn.tensorflow\_compat\_v1.deeponet module
-------------------------------------------------

.. automodule:: deepxde.nn.tensorflow_compat_v1.deeponet
   :members:
   :undoc-members:
   :show-inheritance:

deepxde.nn.tensorflow\_compat\_v1.fnn module
--------------------------------------------

.. automodule:: deepxde.nn.tensorflow_compat_v1.fnn
   :members:
   :undoc-members:
   :show-inheritance:

deepxde.nn.tensorflow\_compat\_v1.mfnn module
---------------------------------------------

.. automodule:: deepxde.nn.tensorflow_compat_v1.mfnn
   :members:
   :undoc-members:
   :show-inheritance:

deepxde.nn.tensorflow\_compat\_v1.msffn module
----------------------------------------------

.. automodule:: deepxde.nn.tensorflow_compat_v1.msffn
   :members:
   :undoc-members:
   :show-inheritance:

deepxde.nn.tensorflow\_compat\_v1.nn module
-------------------------------------------

.. automodule:: deepxde.nn.tensorflow_compat_v1.nn
   :members:
   :undoc-members:
   :show-inheritance:

deepxde.nn.tensorflow\_compat\_v1.resnet module
-----------------------------------------------

.. automodule:: deepxde.nn.tensorflow_compat_v1.resnet
   :members:
   :undoc-members:
   :show-inheritance:

