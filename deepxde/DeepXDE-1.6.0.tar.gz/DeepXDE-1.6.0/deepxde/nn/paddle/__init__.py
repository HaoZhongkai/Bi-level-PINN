"""Package for paddle NN modules."""

__all__ = ["FNN"]

from .fnn import FNN
